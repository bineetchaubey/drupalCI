<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'ming', 'sheng', 'shi', 'yun', 'mian', 'pan', 'fang', 'miao', 'dan', 'mei', 'mao', 'kan', 'xian', 'kou', 'shi', 'yang',
  0x10 => 'zheng', 'yao', 'shen', 'huo', 'da', 'zhen', 'kuang', 'ju', 'shen', 'yi', 'sheng', 'mei', 'mo', 'zhu', 'zhen', 'zhen',
  0x20 => 'mian', 'shi', 'yuan', 'die', 'ni', 'zi', 'zi', 'chao', 'zha', 'xuan', 'bing', 'mi', 'long', 'sui', 'tong', 'mi',
  0x30 => 'die', 'di', 'ne', 'ming', 'xuan', 'chi', 'kuang', 'juan', 'mou', 'zhen', 'tiao', 'yang', 'yan', 'mo', 'zhong', 'mo',
  0x40 => 'zhe', 'zheng', 'mei', 'suo', 'shao', 'han', 'huan', 'di', 'cheng', 'cuo', 'juan', 'e', 'man', 'xian', 'xi', 'kun',
  0x50 => 'lai', 'jian', 'shan', 'tian', 'gun', 'wan', 'leng', 'shi', 'qiong', 'lie', 'ya', 'jing', 'zheng', 'li', 'lai', 'sui',
  0x60 => 'juan', 'shui', 'sui', 'du', 'bi', 'pi', 'mu', 'hun', 'ni', 'lu', 'yi', 'jie', 'cai', 'zhou', 'yu', 'hun',
  0x70 => 'ma', 'xia', 'xing', 'hui', 'gun', 'zai', 'chun', 'jian', 'mei', 'du', 'hou', 'xuan', 'tian', 'kui', 'gao', 'rui',
  0x80 => 'mao', 'xu', 'fa', 'wo', 'miao', 'chou', 'kui', 'mi', 'weng', 'kou', 'dang', 'chen', 'ke', 'sou', 'xia', 'qiong',
  0x90 => 'mo', 'ming', 'man', 'shui', 'ze', 'zhang', 'yi', 'diao', 'kou', 'mo', 'shun', 'cong', 'lou', 'chi', 'man', 'piao',
  0xA0 => 'cheng', 'gui', 'meng', 'huan', 'run', 'pie', 'xi', 'qiao', 'pu', 'zhu', 'deng', 'shen', 'shun', 'liao', 'che', 'xian',
  0xB0 => 'kan', 'ye', 'xu', 'tong', 'mou', 'lin', 'gui', 'jian', 'ye', 'ai', 'hui', 'zhan', 'jian', 'gu', 'zhao', 'qu',
  0xC0 => 'mei', 'chou', 'sao', 'ning', 'xun', 'yao', 'huo', 'meng', 'mian', 'pin', 'mian', 'li', 'kuang', 'jue', 'xuan', 'mian',
  0xD0 => 'huo', 'lu', 'meng', 'long', 'guan', 'man', 'xi', 'chu', 'tang', 'kan', 'zhu', 'mao', 'jin', 'lin', 'yu', 'shuo',
  0xE0 => 'ze', 'jue', 'shi', 'yi', 'shen', 'zhi', 'hou', 'shen', 'ying', 'ju', 'zhou', 'jiao', 'cuo', 'duan', 'ai', 'jiao',
  0xF0 => 'zeng', 'yue', 'ba', 'shi', 'ding', 'qi', 'ji', 'zi', 'gan', 'wu', 'zhe', 'ku', 'gang', 'xi', 'fan', 'kuang',
];
